﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CooperativeFuneralFundInc.Models.SupplyRequest
{
    public class OwnerName
    {
        public int OwnerNameID { get; set; }
        public string OwnerNameName { get; set; }

    }
}
