﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CooperativeFuneralFundInc.Models.SupplyRequest
{
    public class SupplyRequestStatus
    {
        public int SupplyRequestStatusID { get; set; }
        public string SupplyRequestStatusName { get; set; }

        
    }
}
