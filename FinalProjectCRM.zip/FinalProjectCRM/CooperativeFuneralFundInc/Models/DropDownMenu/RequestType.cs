﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CooperativeFuneralFundInc.Models.DropDownMenu
{
    public class RequestType
    {
        public int RequestTypeID { get; set; }
        public string RequestTypeDescription { get; set; }

        
    }
}
